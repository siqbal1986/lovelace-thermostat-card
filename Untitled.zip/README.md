
  # Untitled

  This is a code bundle for Untitled. The original project is available at https://www.figma.com/design/EahAzxQRlHZbZ1e6HJkBJB/Untitled.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  