import { useState, useRef } from "react";
import { ImageCarousel, ImageCarouselHandle } from "./components/ImageCarousel";
import { StatusBar } from "./components/StatusBar";
import { ControlButtons } from "./components/ControlButtons";
import { OptionsList } from "./components/OptionsList";
import {
  Settings,
  Timer,
  MapPin,
  Calendar,
  Users,
  Bell,
  BookOpen,
  Music,
  Video,
  Camera,
  Cpu,
  HardDrive,
} from "lucide-react";

interface MenuButton {
  id: string;
  label: string;
  icon: React.ReactNode;
  color: string;
  options: Array<{ id: string; label: string; icon?: React.ReactNode }>;
}

const menuButtons: MenuButton[] = [
  {
    id: "settings",
    label: "Settings",
    icon: <Settings className="w-5 h-5" />,
    color: "from-blue-500/60 to-blue-600/60",
    options: [
      { id: "general", label: "General Settings" },
      { id: "network", label: "Network Configuration" },
      { id: "security", label: "Security & Privacy" },
      { id: "updates", label: "Software Updates" },
      { id: "language", label: "Language & Region" },
    ],
  },
  {
    id: "schedule",
    label: "Schedule",
    icon: <Timer className="w-5 h-5" />,
    color: "from-purple-500/60 to-purple-600/60",
    options: [
      { id: "daily", label: "Daily Schedule" },
      { id: "weekly", label: "Weekly Schedule" },
      { id: "custom", label: "Custom Schedule" },
      { id: "vacation", label: "Vacation Mode" },
      { id: "quick", label: "Quick Clean" },
      { id: "deep", label: "Deep Clean" },
    ],
  },
  {
    id: "zones",
    label: "Clean Zones",
    icon: <MapPin className="w-5 h-5" />,
    color: "from-green-500/60 to-green-600/60",
    options: [
      { id: "living", label: "Living Room" },
      { id: "kitchen", label: "Kitchen" },
      { id: "bedroom", label: "Bedroom" },
      { id: "bathroom", label: "Bathroom" },
      { id: "hallway", label: "Hallway" },
      { id: "office", label: "Office" },
      { id: "custom-zone", label: "Custom Zone" },
    ],
  },
  {
    id: "history",
    label: "History",
    icon: <Calendar className="w-5 h-5" />,
    color: "from-orange-500/60 to-orange-600/60",
    options: [
      { id: "today", label: "Today's Activity" },
      { id: "week", label: "This Week" },
      { id: "month", label: "This Month" },
      { id: "all", label: "All History" },
    ],
  },
  {
    id: "maintenance",
    label: "Maintenance",
    icon: <Cpu className="w-5 h-5" />,
    color: "from-red-500/60 to-red-600/60",
    options: [
      { id: "filter", label: "Replace Filter" },
      { id: "brush", label: "Clean Brush" },
      { id: "sensors", label: "Clean Sensors" },
      { id: "wheels", label: "Check Wheels" },
      { id: "bin", label: "Empty Bin" },
      { id: "battery", label: "Battery Health" },
      { id: "diagnostics", label: "Run Diagnostics" },
      { id: "calibrate", label: "Calibrate Sensors" },
    ],
  },
  {
    id: "notifications",
    label: "Notifications",
    icon: <Bell className="w-5 h-5" />,
    color: "from-yellow-500/60 to-yellow-600/60",
    options: [
      { id: "alerts", label: "Alert Settings" },
      { id: "email", label: "Email Notifications" },
      { id: "push", label: "Push Notifications" },
    ],
  },
  {
    id: "modes",
    label: "Cleaning Modes",
    icon: <BookOpen className="w-5 h-5" />,
    color: "from-cyan-500/60 to-cyan-600/60",
    options: [
      { id: "auto", label: "Auto Mode" },
      { id: "spot", label: "Spot Cleaning" },
      { id: "edge", label: "Edge Cleaning" },
      { id: "max", label: "Max Power" },
      { id: "quiet", label: "Quiet Mode" },
      { id: "turbo", label: "Turbo Mode" },
      { id: "mop", label: "Mop Mode" },
      { id: "vacuum", label: "Vacuum Only" },
      { id: "combo", label: "Vacuum + Mop" },
    ],
  },
  {
    id: "voice",
    label: "Voice Control",
    icon: <Music className="w-5 h-5" />,
    color: "from-pink-500/60 to-pink-600/60",
    options: [
      { id: "alexa", label: "Amazon Alexa" },
      { id: "google", label: "Google Assistant" },
      { id: "siri", label: "Apple Siri" },
      { id: "custom", label: "Custom Commands" },
    ],
  },
  {
    id: "media",
    label: "Media",
    icon: <Video className="w-5 h-5" />,
    color: "from-indigo-500/60 to-indigo-600/60",
    options: [
      { id: "photos", label: "Cleaning Photos" },
      { id: "videos", label: "Activity Videos" },
      { id: "timelapse", label: "Time-lapse" },
      { id: "export", label: "Export Media" },
      { id: "share", label: "Share" },
    ],
  },
  {
    id: "family",
    label: "Family Sharing",
    icon: <Users className="w-5 h-5" />,
    color: "from-teal-500/60 to-teal-600/60",
    options: [
      { id: "members", label: "Family Members" },
      { id: "permissions", label: "Permissions" },
      { id: "invite", label: "Invite User" },
    ],
  },
  {
    id: "camera",
    label: "Camera",
    icon: <Camera className="w-5 h-5" />,
    color: "from-violet-500/60 to-violet-600/60",
    options: [
      { id: "live", label: "Live View" },
      { id: "snapshots", label: "Snapshots" },
      { id: "motion", label: "Motion Detection" },
      { id: "privacy", label: "Privacy Mode" },
      { id: "quality", label: "Video Quality" },
      { id: "storage", label: "Storage Settings" },
    ],
  },
  {
    id: "storage",
    label: "Storage",
    icon: <HardDrive className="w-5 h-5" />,
    color: "from-emerald-500/60 to-emerald-600/60",
    options: [
      { id: "usage", label: "Storage Usage" },
      { id: "maps", label: "Saved Maps" },
      { id: "logs", label: "Activity Logs" },
      { id: "cache", label: "Clear Cache" },
      { id: "backup", label: "Backup Data" },
      { id: "restore", label: "Restore Data" },
      { id: "export-data", label: "Export All Data" },
      { id: "delete", label: "Delete All Data" },
    ],
  },
];

export default function App() {
  const [activeSubmenu, setActiveSubmenu] = useState<string | null>(null);
  const carouselRef = useRef<ImageCarouselHandle>(null);

  const handleButtonClick = (buttonId: string) => {
    // Toggle menu - close if already open, open if closed
    if (activeSubmenu === buttonId) {
      setActiveSubmenu(null);
    } else {
      setActiveSubmenu(buttonId);
      // Move carousel to associated image
      if (carouselRef.current) {
        carouselRef.current.goToSlide(buttonId);
      }
    }
  };

  const handleOptionClick = (optionId: string) => {
    console.log("Selected option:", optionId);
    setActiveSubmenu(null);
  };

  const activeMenu = menuButtons.find((btn) => btn.id === activeSubmenu);

  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 p-8">
      <div className="w-[1200px] h-[600px] flex flex-col bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/20 overflow-hidden">
        {/* Status Bar - Full Width Row */}
        <StatusBar />

        {/* Control Buttons - Full Width Row */}
        <ControlButtons />

        {/* Main Content Area */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Side - Carousel with Options Overlay */}
          <div className="w-[480px] p-4 relative">
            <div className="relative w-full h-full">
              <ImageCarousel ref={carouselRef} />
              {activeMenu && (
                <OptionsList
                  isOpen={activeSubmenu !== null}
                  options={activeMenu.options}
                  onOptionClick={handleOptionClick}
                />
              )}
            </div>
          </div>

          {/* Right Side - Button Grid */}
          <div className="flex-1 p-4 overflow-y-auto">
            <div className="grid grid-cols-2 gap-3">
              {menuButtons.map((button) => (
                <button
                  key={button.id}
                  onClick={() => handleButtonClick(button.id)}
                  className={`relative bg-gradient-to-br ${button.color} backdrop-blur-md text-white p-5 rounded-2xl shadow-lg hover:shadow-2xl transition-all transform hover:scale-105 active:scale-95 border border-white/30 overflow-hidden group`}
                >
                  {/* Glass reflection effect */}
                  <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-transparent opacity-50"></div>
                  <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/20 to-transparent opacity-60"></div>
                  <div className="absolute bottom-0 left-0 right-0 h-px bg-white/40"></div>
                  
                  {/* Shine effect on hover */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent translate-x-[-200%] group-hover:translate-x-[200%] transition-transform duration-700 ease-in-out"></div>
                  
                  {/* Content */}
                  <div className="relative z-10">
                    <div className="flex items-center gap-3">
                      {button.icon}
                      <span className="font-semibold text-base">{button.label}</span>
                    </div>
                    <div className="mt-2 text-xs opacity-90">
                      {button.options.length} options
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
