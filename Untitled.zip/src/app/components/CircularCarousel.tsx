import { motion } from "motion/react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";

interface SubmenuOption {
  id: string;
  label: string;
  icon?: React.ReactNode;
}

interface CircularCarouselProps {
  title: string;
  options: SubmenuOption[];
  onClose: () => void;
  onOptionClick: (optionId: string) => void;
}

export function CircularCarousel({
  title,
  options,
  onClose,
  onOptionClick,
}: CircularCarouselProps) {
  const [rotation, setRotation] = useState(0);
  const itemsPerView = Math.min(6, options.length);
  const angleStep = 360 / itemsPerView;
  const radius = 180;

  const rotateNext = () => {
    setRotation((prev) => prev - angleStep);
  };

  const rotatePrev = () => {
    setRotation((prev) => prev + angleStep);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      className="flex flex-col items-center justify-center h-full bg-gradient-to-br from-gray-50 to-gray-100 p-8 rounded-2xl"
    >
      {/* Header */}
      <div className="flex items-center justify-between w-full mb-8">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          {title}
        </h2>
        <button
          onClick={onClose}
          className="bg-red-500 hover:bg-red-600 text-white rounded-full p-2 transition-colors"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      {/* Circular Carousel Container */}
      <div className="relative flex-1 flex items-center justify-center w-full">
        <div className="relative w-full h-full max-w-2xl max-h-[500px]">
          {/* Center Circle */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full shadow-2xl flex items-center justify-center z-10">
            <span className="text-white font-bold text-center px-4">
              Select Option
            </span>
          </div>

          {/* Circular Options */}
          <motion.div
            className="absolute inset-0"
            animate={{ rotate: rotation }}
            transition={{ type: "spring", stiffness: 100, damping: 20 }}
          >
            {options.map((option, index) => {
              const angle = (index * 360) / options.length;
              const x = Math.cos((angle * Math.PI) / 180) * radius;
              const y = Math.sin((angle * Math.PI) / 180) * radius;

              return (
                <motion.div
                  key={option.id}
                  className="absolute top-1/2 left-1/2"
                  style={{
                    transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y}px))`,
                  }}
                >
                  <motion.button
                    animate={{ rotate: -rotation }}
                    transition={{ type: "spring", stiffness: 100, damping: 20 }}
                    onClick={() => onOptionClick(option.id)}
                    className="bg-white hover:bg-gradient-to-br hover:from-blue-500 hover:to-purple-600 hover:text-white text-gray-800 px-6 py-4 rounded-2xl shadow-lg hover:shadow-2xl transition-all transform hover:scale-110 border-2 border-gray-200 hover:border-transparent min-w-[140px]"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <div className="flex flex-col items-center gap-2">
                      {option.icon && (
                        <span className="text-2xl">{option.icon}</span>
                      )}
                      <span className="font-semibold text-sm text-center">
                        {option.label}
                      </span>
                    </div>
                  </motion.button>
                </motion.div>
              );
            })}
          </motion.div>
        </div>

        {/* Navigation Buttons */}
        {options.length > itemsPerView && (
          <>
            <button
              onClick={rotatePrev}
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-blue-500 hover:bg-blue-600 text-white rounded-full p-4 shadow-lg transition-all z-20"
            >
              <ChevronLeft className="w-8 h-8" />
            </button>
            <button
              onClick={rotateNext}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-blue-500 hover:bg-blue-600 text-white rounded-full p-4 shadow-lg transition-all z-20"
            >
              <ChevronRight className="w-8 h-8" />
            </button>
          </>
        )}
      </div>

      {/* Option Counter */}
      <div className="mt-8 text-gray-600 font-medium">
        {options.length} options available
      </div>
    </motion.div>
  );
}
