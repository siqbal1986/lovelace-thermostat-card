import { motion } from "motion/react";
import { Play, Square, Pause, ArrowLeft, Home, Trash2, Droplets, Wind } from "lucide-react";

interface ControlButton {
  icon: React.ReactNode;
  label: string;
  color: string;
  hoverColor: string;
}

const controls: ControlButton[] = [
  { icon: <Play className="w-5 h-5" />, label: "Start", color: "bg-green-500/60", hoverColor: "hover:bg-green-500/70" },
  { icon: <Square className="w-5 h-5" />, label: "Stop", color: "bg-red-500/60", hoverColor: "hover:bg-red-500/70" },
  { icon: <Pause className="w-5 h-5" />, label: "Pause", color: "bg-yellow-500/60", hoverColor: "hover:bg-yellow-500/70" },
  { icon: <ArrowLeft className="w-5 h-5" />, label: "Go Back", color: "bg-gray-500/60", hoverColor: "hover:bg-gray-500/70" },
  { icon: <Home className="w-5 h-5" />, label: "Home", color: "bg-blue-500/60", hoverColor: "hover:bg-blue-500/70" },
  { icon: <Trash2 className="w-5 h-5" />, label: "Self Empty", color: "bg-purple-500/60", hoverColor: "hover:bg-purple-500/70" },
  { icon: <Droplets className="w-5 h-5" />, label: "Wash", color: "bg-cyan-500/60", hoverColor: "hover:bg-cyan-500/70" },
  { icon: <Wind className="w-5 h-5" />, label: "Dry", color: "bg-orange-500/60", hoverColor: "hover:bg-orange-500/70" },
];

export function ControlButtons() {
  return (
    <div className="bg-white/10 backdrop-blur-md border-b border-white/20 px-4 py-4">
      <div className="flex items-center gap-3 flex-wrap">
        {controls.map((control, index) => (
          <motion.button
            key={control.label}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{
              delay: index * 0.1,
              type: "spring",
              stiffness: 260,
              damping: 20,
            }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className={`relative ${control.color} ${control.hoverColor} backdrop-blur-md text-white px-4 py-3 rounded-xl shadow-lg hover:shadow-2xl transition-all flex items-center gap-2 border border-white/30 overflow-hidden group`}
          >
            {/* Glass reflection effects */}
            <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-transparent opacity-50"></div>
            <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/20 to-transparent opacity-60"></div>
            <div className="absolute bottom-0 left-0 right-0 h-px bg-white/40"></div>
            
            {/* Shine effect on hover */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent translate-x-[-200%] group-hover:translate-x-[200%] transition-transform duration-700 ease-in-out"></div>
            
            {/* Content */}
            <motion.div
              className="relative z-10"
              animate={{
                rotate: [0, 10, -10, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatDelay: 3,
              }}
            >
              {control.icon}
            </motion.div>
            <span className="relative z-10 font-medium text-sm">{control.label}</span>
          </motion.button>
        ))}
      </div>
    </div>
  );
}
