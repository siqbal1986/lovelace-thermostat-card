import { motion, AnimatePresence } from "motion/react";
import { X } from "lucide-react";

interface SubmenuOption {
  id: string;
  label: string;
  icon?: React.ReactNode;
}

interface FancySubmenuProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  options: SubmenuOption[];
  onOptionClick: (optionId: string) => void;
}

export function FancySubmenu({
  isOpen,
  onClose,
  title,
  options,
  onOptionClick,
}: FancySubmenuProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
          />

          {/* Submenu Panel */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-md"
          >
            <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
              {/* Header */}
              <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-blue-500 to-purple-600">
                <h3 className="text-white text-lg font-semibold">{title}</h3>
                <button
                  onClick={onClose}
                  className="text-white hover:bg-white/20 rounded-full p-1.5 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Options Grid */}
              <div className="p-4 max-h-[60vh] overflow-y-auto">
                <div className="grid grid-cols-1 gap-2">
                  {options.map((option, index) => (
                    <motion.button
                      key={option.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      onClick={() => {
                        onOptionClick(option.id);
                        onClose();
                      }}
                      className="flex items-center gap-3 px-4 py-3 rounded-lg bg-gray-50 hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 border border-gray-200 hover:border-blue-300 transition-all group"
                    >
                      {option.icon && (
                        <span className="text-gray-600 group-hover:text-blue-600 transition-colors">
                          {option.icon}
                        </span>
                      )}
                      <span className="text-gray-800 group-hover:text-blue-700 font-medium">
                        {option.label}
                      </span>
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
