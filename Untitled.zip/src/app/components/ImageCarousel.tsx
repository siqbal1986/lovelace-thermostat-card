import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { useRef, useImperativeHandle, forwardRef } from "react";

const carouselImages = [
  {
    url: "https://images.unsplash.com/photo-1558317374-067fb5f30001?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb2JvdCUyMHZhY3V1bSUyMGNsZWFuZXJ8ZW58MXx8fHwxNzcxMDA5MDc1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    alt: "Robot Vacuum Cleaner",
    category: "zones",
  },
  {
    url: "https://images.unsplash.com/photo-1753039495488-434a2fe53e41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydCUyMGhvbWUlMjBkZXZpY2V8ZW58MXx8fHwxNzcwOTkyMjA2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    alt: "Smart Home Device",
    category: "settings",
  },
  {
    url: "https://images.unsplash.com/photo-1770625467638-964f594712e3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBhcHBsaWFuY2UlMjBkaXNwbGF5fGVufDF8fHx8MTc3MTA0MjYxNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    alt: "Modern Appliance",
    category: "maintenance",
  },
  {
    url: "https://images.unsplash.com/photo-1762500825366-ba34b0c5352e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGVhbmluZyUyMHJvYm90JTIwdGVjaG5vbG9neXxlbnwxfHx8fDE3NzEwNDI2MTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    alt: "Cleaning Robot",
    category: "modes",
  },
];

export interface ImageCarouselHandle {
  goToSlide: (category: string) => void;
}

export const ImageCarousel = forwardRef<ImageCarouselHandle>((props, ref) => {
  const sliderRef = useRef<Slider>(null);

  useImperativeHandle(ref, () => ({
    goToSlide: (category: string) => {
      const index = carouselImages.findIndex((img) => img.category === category);
      if (index !== -1 && sliderRef.current) {
        sliderRef.current.slickGoTo(index);
      }
    },
  }));

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    arrows: true,
  };

  return (
    <div className="w-full h-full bg-gray-900/20 rounded-lg overflow-hidden backdrop-blur-sm">
      <Slider ref={sliderRef} {...settings}>
        {carouselImages.map((image, index) => (
          <div key={index} className="relative h-full">
            <img
              src={image.url}
              alt={image.alt}
              className="w-full h-full object-cover"
              style={{ height: "100%" }}
            />
          </div>
        ))}
      </Slider>
    </div>
  );
});

ImageCarousel.displayName = "ImageCarousel";
