import { motion, AnimatePresence } from "motion/react";

interface SubmenuOption {
  id: string;
  label: string;
  icon?: React.ReactNode;
}

interface OptionsListProps {
  isOpen: boolean;
  options: SubmenuOption[];
  onOptionClick: (optionId: string) => void;
}

export function OptionsList({ isOpen, options, onOptionClick }: OptionsListProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -50 }}
          transition={{ type: "spring", damping: 25, stiffness: 300 }}
          className="absolute inset-0 bg-black/5 backdrop-blur-sm rounded-lg p-6 overflow-y-auto z-10"
        >
          <div className="space-y-3">
            {options.map((option, index) => (
              <motion.button
                key={option.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => onOptionClick(option.id)}
                className="relative w-full flex items-center gap-3 px-4 py-4 rounded-xl bg-white/5 backdrop-blur-md hover:bg-white/15 border border-white/15 hover:border-white/30 transition-all group shadow-lg overflow-hidden"
              >
                {/* Glass reflection effects */}
                <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-transparent opacity-50"></div>
                <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/15 to-transparent opacity-60"></div>
                <div className="absolute bottom-0 left-0 right-0 h-px bg-white/25"></div>
                
                {/* Shine effect on hover */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-200%] group-hover:translate-x-[200%] transition-transform duration-700 ease-in-out"></div>
                
                {/* Content */}
                {option.icon && (
                  <span className="relative z-10 text-white/90 group-hover:text-white transition-colors drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                    {option.icon}
                  </span>
                )}
                <span className="relative z-10 text-white font-semibold text-lg group-hover:text-white/100 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                  {option.label}
                </span>
              </motion.button>
            ))}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
