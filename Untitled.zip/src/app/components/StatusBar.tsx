import { motion } from "motion/react";
import { Battery, Wifi, Thermometer, Droplets, Clock, Zap, Shield, Signal } from "lucide-react";

interface StatusItem {
  icon: React.ReactNode;
  label: string;
  value: string;
  color: string;
}

const statusItems: StatusItem[] = [
  { icon: <Battery className="w-4 h-4" />, label: "Battery", value: "87%", color: "text-green-400" },
  { icon: <Wifi className="w-4 h-4" />, label: "WiFi", value: "Strong", color: "text-blue-400" },
  { icon: <Thermometer className="w-4 h-4" />, label: "Temp", value: "22°C", color: "text-orange-400" },
  { icon: <Droplets className="w-4 h-4" />, label: "Water", value: "Full", color: "text-cyan-400" },
  { icon: <Clock className="w-4 h-4" />, label: "Runtime", value: "2h 15m", color: "text-purple-400" },
  { icon: <Zap className="w-4 h-4" />, label: "Power", value: "Active", color: "text-yellow-400" },
  { icon: <Shield className="w-4 h-4" />, label: "Status", value: "OK", color: "text-emerald-400" },
  { icon: <Signal className="w-4 h-4" />, label: "Signal", value: "100%", color: "text-indigo-400" },
];

export function StatusBar() {
  return (
    <div className="bg-white/10 backdrop-blur-md border-b border-white/20 px-4 py-3">
      <div className="flex items-center gap-4 overflow-x-auto">
        {statusItems.map((item, index) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="relative flex items-center gap-2 min-w-fit bg-white/20 backdrop-blur-md px-3 py-2 rounded-lg shadow-lg border border-white/30 overflow-hidden group cursor-pointer hover:shadow-xl transition-all"
          >
            {/* Glass reflection effects */}
            <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-transparent opacity-50"></div>
            <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/20 to-transparent opacity-60"></div>
            <div className="absolute bottom-0 left-0 right-0 h-px bg-white/40"></div>
            
            {/* Shine effect on hover */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent translate-x-[-200%] group-hover:translate-x-[200%] transition-transform duration-700 ease-in-out"></div>
            
            {/* Content */}
            <span className={`relative z-10 ${item.color}`}>{item.icon}</span>
            <div className="relative z-10 flex flex-col">
              <span className="text-xs text-white/70">{item.label}</span>
              <span className="text-sm font-semibold text-white">{item.value}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
